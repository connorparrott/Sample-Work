package Lab7;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.TreeSet;

public class Main {

    //METHODS:

    private static Integer higher(HashSet<Integer> hashSet, int value) {
        //Return the least element that is greater than the given element
        Object[] myArray = hashSet.toArray();
        Arrays.sort(myArray);
        int index = Arrays.binarySearch(myArray, value);
        if(index >= 0) {
            if(index + 1 < myArray.length) {
                return (Integer) myArray[index + 1];
            }
        }
        return null;
    }

    private static Integer ceiling(HashSet<Integer> hashSet, int value) {
        //returns the least element that is greater than or equal to the given element
        Object[] myArray = hashSet.toArray();
        Arrays.sort(myArray);
        int index = Arrays.binarySearch(myArray, value);
        if(index >= 0) {
            if(index + 1 < myArray.length) {
                return (Integer) myArray[index + 1];
            } else {
                return (Integer) myArray[index];
            }
        }
        return null;
    }


//TESTING

    public static void main(String[] args) {
        int[] sizes = {500000, 750000, 1000000, 1250000, 1500000, 2000000, 5000000, 10000000};
        double hashSetCeilingAverage = 0;
        double hashSetHigherAverage = 0;
        double treeSetCeilingAverage = 0;
        double treeSetHigherAverage = 0;

        HashSet<Integer> hashSet = new HashSet<>();
        TreeSet<Integer> tree = new TreeSet<>();
        long seed = System.currentTimeMillis();      
        
        for (int size : sizes) {
            System.out.println("Size,Iteration,Insertion_time,Search_time");
            for (int i = 0; i < size; i++) {  // choose an amount of data to add to array like 10k
                Random r = new Random(seed);
                hashSet.add(r.nextInt());
                tree.add(r.nextInt());
            }
            for (int iteration = 0; iteration < 10; iteration++) {
                Random r = new Random(seed);
                
                // Higher TEST
                long startTime = System.nanoTime();
                for (int i = 0; i < size; i++) {
                    higher(hashSet, r.nextInt());
                }
                long elapsedTime = System.nanoTime() - startTime;
                hashSetHigherAverage += (elapsedTime / 1000000000.0);
                System.out.print((elapsedTime / 1000000000.0));

                //CEILING TEST
                startTime = System.nanoTime();
                for (int i = 0; i < size; i++) {
                    ceiling(hashSet, r.nextInt());
                }
                elapsedTime = System.nanoTime() - startTime;
                hashSetCeilingAverage += (elapsedTime / 1000000000.0);
                System.out.print("," + (elapsedTime / 1000000000.0));

                //TREEEE

                // Higher
                startTime = System.nanoTime();
                for (int i = 0; i < size; i++) {
                    tree.higher(r.nextInt());
                }
                elapsedTime = System.nanoTime() - startTime;
                treeSetHigherAverage += (elapsedTime / 1000000000.0);
                System.out.print("," + (elapsedTime / 1000000000.0));

                // Ceiling
                startTime = System.nanoTime();
                for (int i = 0; i < size; i++) {
                    tree.ceiling(r.nextInt());
                }
                elapsedTime = System.nanoTime() - startTime;
                treeSetCeilingAverage += (elapsedTime / 1000000000.0);
                System.out.println("," + (elapsedTime / 1000000000.0));
            }

            System.out.println();
            System.out.println("HashSet Higher Average: " + (hashSetHigherAverage)/10);
            System.out.println("HashSet Ceiling Average: " + (hashSetCeilingAverage)/10);
            System.out.println("TreeSet Ceiling Average: " + (treeSetCeilingAverage)/10);
            System.out.println("Set Higher Average: " + (treeSetHigherAverage)/10);
            System.out.println();
        }
    }
}