#include"address.h"

using namespace std;

istream& operator>>(istream& input, address &a){
    string temp;
    input >> temp;
    if(input.eof()){
        return input;
    }

    //set first octet
    //cout << "temp is: " << temp << endl;
    size_t pos0 = 0;
    size_t pos1 = temp.find(".");
    string toPrint = temp.substr(pos0, pos1);
    temp = temp.substr(pos1 + 1);
    //cout << "To print is: " << toPrint << endl;
    address newAddress;
    a.set_octet1(stoi(toPrint));
    
    //set second octet
    //cout << "temp is: "<< temp << endl;
    pos0 = 0;
    pos1 = temp.find(".");
    toPrint = temp.substr(pos0, pos1);
    temp = temp.substr(pos1 + 1);
    //cout << "to print is: " << toPrint << endl;
    a.set_octet2(stoi(toPrint));
    
    //set third octet
    //cout << "temp is: " << temp << endl;
    pos0 = 0;
    pos1 = temp.find(".");
    toPrint = temp.substr(pos0, pos1);
    temp = temp.substr(pos1 + 1);
    //cout << "to print is: " << toPrint << endl;
    a.set_octet3(stoi(toPrint));
    
    //setfourth octet
    //cout << "Temp is : " << temp << endl;
    pos0 = 0;
    toPrint = temp.substr(pos0);
    //cout << "to print is: " << toPrint << endl;
    a.set_octet4(stoi(toPrint));
    return input;
}

ostream& operator<<(ostream& output, address &a){
    //cout << "the network's class is: " << a.get_netID() << endl;
    if(a.get_netID() == 'a'){
        cout << "Network: " << a.get_octet1() << " Host: " << a.get_octet2() << "." << a.get_octet3() << "." << a.get_octet4() << endl;
    } else if(a.get_netID() == 'b'){
        cout << "Network: " << a.get_octet1() << "." << a.get_octet2() << " Host: " << a.get_octet3() << "." << a.get_octet4() << endl;
    } else if(a.get_netID() == 'c'){
        cout << "Network: " << a.get_octet1() << " Host: " << a.get_octet2() << "." << a.get_octet3() << "." << a.get_octet4() << endl;
    } else{
        //cout << "this network address doesnt belong to class a, b or c\n";
    }
    //output << a.get_octet1() << "." << a.get_octet2() << "." << a.get_octet3() << "." << a.get_octet4() << endl;
    return output;
}

void readIn(vector<address> &input){
    ifstream ifs;
    ifs.open("/public/lab7/addresses.txt");
    
    if(!ifs.is_open()){
        cout << "ERROR: Unable to open file\n";
    }
    
    address temp;
    //need to overload >> so that it will read as an address (thus directly putting it in the array I want.
    while(ifs >> temp){
        input.push_back(temp);
    }
    ifs.close();
}

bool compare(address a1, address a2){
    return (a1.get_octet1() < a2.get_octet1());
}

int main(){
    vector<address> classA;
    vector<address> classB;
    vector<address> classC;
    vector<address> input;
    readIn(input);
    for(address temp : input){
        if(temp.get_octet1() < 128){
            temp.set_netID('a');
            classA.push_back(temp);
            
        } else if(temp.get_octet1() < 192){
            temp.set_netID('b');
            classB.push_back(temp);
        } else if(temp.get_octet1() < 224){
            temp.set_netID('c');
            classC.push_back(temp);
        }
    }
    cout << "printing all of the addresses\n";
    
    sort(classA.begin(), classA.end(), compare);
    sort(classB.begin(), classB.end(), compare);
    sort(classC.begin(), classC.end(), compare);

    cout << "Class A has " << classA.size() << " network addresses:\n";
    for(address temp : classA){
        cout << temp;
    }
    cout << "Class B has " << classB.size() << " network addresses:\n";
    for(address temp : classB){
        cout << temp;
    }
    cout << "Class C has " << classC.size() << " network addresses:\n";
    for(address temp : classC){
        cout << temp;
    }
    
    
}
