//includes here
#include<iostream>
#include<istream>
#include<fstream>
#include<vector>
#include<string>
#include<sstream>
#include<algorithm>

using namespace std;

class address{
    private:
        int octet1;
        int octet2;
        int octet3;
        int octet4;
        char netID;
    public:
        address(int firstOctet){
            octet1 = firstOctet;
            netID = 'f';
        }
        address(int firstOctet, int secondOctet, int thirdOctet, int fourthOctet){
            octet1 = firstOctet;
            octet2 = secondOctet;
            octet3 = thirdOctet;
            octet4 = fourthOctet;
            netID = 'f';
        }
        address(){
            netID = 'f';
        }
        void set_netID(char a){ netID = a; }
        void set_octet1(int o){ octet1 = o; }
        void set_octet2(int o){ octet2 = o; }
        void set_octet3(int o){ octet3 = o; }
        void set_octet4(int o){ octet4 = o; }
        char get_netID(){ return netID; }
        int get_octet1(){ return octet1; }
        int get_octet2(){ return octet2; }
        int get_octet3(){ return octet3; }
        int get_octet4(){ return octet4; }
        friend istream& operator>>(istream&, address&);
        friend ostream& operator<<(ostream&, address&);        
};


