#include<string>
#include<iostream>
#include<vector>

using namespace std;

class Term{
  private:
    int coefficient;
    int exponent;
  public:
    Term(){
        coefficient = 0;
        exponent = 0;
    }
    Term(int c, int e){
        coefficient = c;
        exponent = e;
    }
    void set_coefficient(int c){coefficient = c;}
    void set_exponent(int e){exponent = e;}
    int get_coefficient(){return coefficient;}
    int get_exponent(){return exponent;}
};

class Equation{
  //private:
  //  vector<Term> equation;
  public:
    vector<Term> equation;
    void read_in(string temp, string op)
    {
        
        bool isDone = true;
        //read from file and add the terms to the equation vector.
        while(!isDone) 
        {
            cin >> temp >> op;
            int coefficient;
            int exponent;
    
    //process temp and add it to the polynomial vector.
            
            if(temp.length() == 3)
            {
                coefficient = atoi(temp.at(0));
                exponent = atoi(temp.at(2));
            }
            
            
            else if(temp.length() == 2)
            {
                if(temp.at(0) == "x")
                {
                    coefficient = 1;
                    exponent = atoi(temp.at(1));
                } 
                else if(temp.at(1) == "x")
                {
                    coefficient = atoi(temp.at(0));
                    exponent = 1;
                }
            } 
            else if(temp.length() == 1)
            {
                coefficient = atoi(temp.at(0));
                exponent = 0;
            }
        //create term and add it to the vector.
            Term new_term = Term(coefficient, exponent);
            eq1.push_back(new_term);
            if(op.eof())
            {
                isDone = true;
            } 
        }
    }
    void print()
    {
        for(Term s : equation)
        {
            cout << s.get_coefficient() << "X" << s.get_exponent() << " + ";
        }
    }
};

int main(){
    Equation eq1;
    //read from file and add the terms to the equation vector.
    string temp;
    string op;
    cin >> temp >> op;

    eq1.read_in(temp, op);
    eq1.print();
    

    //check length to determine
        //for length 2
        //if first item is x, set coefficient to 1
        //if first item is num, set coefficient to 0


    //add like terms
    //big while loop (check if vector is empty
        //find the highest term
        //pull off things with same exponent
        //add coefficient
        //"erase" from the original vector 

    //print terms}
    return(1);
}

