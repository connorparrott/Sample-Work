#include<string>
#include<iostream>
#include<vector>
#include<sstream>
#include<fstream>


using namespace std;

class Employee: public Person{
    private:
        string empType;
        string dept;
        int creditsAvail;
    public:
        Employee(vector<string> a){
            fName = a.at(1); 
            lName = a.at(0); //last name is first in the list
            name = fName + " " + lName;
            id = a.at(2);
            empType = a.at(3);
            dept = a.at(4);
            
            //sets the credits avaialbe if the employee is part time or full time
            if(empType == "PT"){
                creditsAvail = 3;
            } else if(empType == "FT"){
                creditsAvail = 7;
            }
        }
        //getter methods
        string getName(){ return name; }
        string getEmpType(){ return empType; }
        string getDept(){ return dept; }
        int getCreditsAvail(){ return creditsAvail; }
};

 Employee splitEmployee(string line){
            vector<string> words;
            string temp;
            stringstream s(line);
            
            //splits the line storing the attributes of the employee
            while(getline(s, temp, ',')){
                words.push_back(temp);
            }
            Employee newEmployee = Employee(words);
            return newEmployee;
        }

        void ReadEmployee(vector<Employee>& emp){
            string line;
            int counter = 0;
            //opens file
            ifstream ifs {"/public/pgm2/employees.csv"};
            if(!ifs.is_open()){
                cout << "File isn't open\n";
            }
            
            //create an employee for each line in the file
            while (getline(ifs, line)){
                emp.push_back(splitEmployee(line));
                counter++;
            }

            ifs.close();
        }

