#include<string>
#include<vector>
#include<sstream>

using namespace std;

class UnivClass{
    private:
        string cNumber;
        string title;
        int totalSeats;
        int seatsLeft;
        int crn; //will be unused but stored regardless
        string professor;
        string dateTime;
        string location;
        int credits;
    public:
        //constructor
        UnivClass(vector<string> c){
            cNumber = c.at(0);
            title = c.at(1);
            crn = stoi(c.at(2));
            totalSeats = stoi(c.at(3));
            //skip c.at(4) as it holds the number of seats taken.
            seatsLeft = stoi(c.at(5));
            professor = c.at(6);
            dateTime = c.at(7);
            location = c.at(8);
            credits = stoi(c.at(9));
        }

        //getters
        string getcNumber(){ return cNumber; }
        string getTitle(){ return title; }
        int getTotalSeats(){ return totalSeats; }
        int getSeatsLeft(){ return seatsLeft; }
        string getProfessor(){ return professor; }
        string getDateTime(){ return dateTime; }
        string getLocation(){ return location; }
        int getCredits(){ return credits; }
};

  UnivClass splitClass(string line){
        //create a istringstream from line
        //use getLine with 3 parameters to pull eachs string
        vector<string> words;
        string temp;
        stringstream s(line);
        while(getline(s, temp, ',')){
            words.push_back(temp);
        }
        UnivClass newClass = UnivClass(words);
        return newClass;
    }

void ReadUnivClass(vector<UnivClass>& classes){
    string line;
    ifstream ifs {"/public/pgm2/classes.csv"};
    if(!ifs.is_open()){
        cout << "File isn't open\n";
    }
    //create a class for each line in the 
    while (getline(ifs, line)){
        classes.push_back(splitClass(line));
    }
    ifs.close();
}

