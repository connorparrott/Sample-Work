#include<string>
#include<iostream>
#include<vector>
#include<sstream>
#include<fstream>
#include"Person.h"

using namespace std;

class Student: public Person {
    private:
        int creditsAvail;
        int creditsEarned;
    public:
        Student(vector<string> a){
            //creates a student from a vector of attributes.
            fName = a.at(1);
            lName = a.at(0); //last name is first in the file
            name = fName + " " + lName;
            id = a.at(2);
            creditsEarned = stoi(a.at(3));
            creditsAvail = 21;
        }
        //friend operator<<();
        string getName(){ return name; }
        int getCreditsAvail(){ return creditsAvail; }
        int getCreditsEarned(){ return creditsEarned; }

};

    Student splitStudent(string line){
        vector<string> words; //holds the attributes of a student
        string temp; //holds each word individually
        stringstream s(line); //creates input stream to read from
        
        //breaks the string apart and stores the attributes of a student in a vector
        while(getline(s, temp, ',')){
            words.push_back(temp);
        }
        Student newStudent = Student(words);
        return newStudent;
    }


void ReadStudent(vector<Student>& stud){
    string line;
    int counter = 0;
    //open the file
    ifstream ifs {"/public/pgm2/students.csv"};
    if(!ifs.is_open()){
        cout << "File isn't open\n";
    }
    
    //reads each line and passes it to the split function to make them into a vector of students
    while (getline(ifs, line)){
        stud.push_back(splitStudent(line));
        //for testing, shows all of the students available.
        //cout << "First student's name is " <<  stud.at(counter).getName() << endl;
        counter++;
    }

    ifs.close();
}

