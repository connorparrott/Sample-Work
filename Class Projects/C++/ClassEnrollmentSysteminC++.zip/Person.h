#include<string>

using namespace std;

class Person {
    protected:
        string fName;
        string lName;
        string name;
        string id;
    public:
        //constructor
        Person(){
            fName = "";
            lName = "";
            name = fName + " " + lName;
            id = "";
        }
        Person(string f, string l, string i){
            fName = f;
            lName = l;
            name = fName + " " + lName;
            id = i;
        }
        //getters

        friend ostream& operator<<(ostream&, Person);
        string getfName(){ return fName; }
        string getlName(){ return lName; }
        string getName(){ return name; }
        string getId(){ return id; }
        bool isName(string temp){
            if(name.compare(temp) != 0){
                return false;
            }
            return true;
        }
};

