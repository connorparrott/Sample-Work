#include<string>
#include<iostream>
#include<fstream>
#include"UnivClass.h"
#include"Student.h"
#include"Employee.h"

using namespace std;

//overload output operator for student
ostream& operator<<(ostream& output, Student &s){    
    output << "Student Name: " << s.getName() << " ID: " << s.getId() << " Current Credits: " << s.getCreditsEarned();
    return output;
}

//overload output operator for employee
ostream& operator<<(ostream& output, Employee &e){
    output << "Employee Name: " << e.getName() << " ID: " << e.getId() << " Type: " << e.getEmpType() << " Works in: " << e.getDept();
    return output;
}

//overload output operator for class
ostream& operator<<(ostream& output, UnivClass &c){
    output << c.getcNumber() << " " << c.getTitle() << " " << " Taught by " << c.getProfessor() << " at " << c.getDateTime() << " in " << c.getLocation();
    return output;
}

//searches through the Students and Employees and returns the number of credits the person has taken in the past. Also prints the information of the student/employee
int FindPrintName(vector<Student> studList, vector<Employee> empList, string name){
    //search through each student to see if the person entered is a student. returns the credits taken, or zero if nothing is found.
    for(Student student : studList){
        if(name == student.getName()){
            cout << student << endl;  
            return student.getCreditsAvail();
        }
    }

    //search through each employee to see if the person entered is an employee. returns the credits taken, or zero if nothing is found. 
    for(Employee employee : empList){
        if(name == employee.getName()){
            cout << employee << endl;
            return employee.getCreditsAvail();
        }
    }
    return(0);
}


//prints the classes and checks to see if the classes to register for and registers the person for the classes. Only registers for the number of classes the person has credits available for.
void PrintClassSchedule(vector<UnivClass> classList, vector<string> toRegister, int creditsAvail){
    int numCredits = 0;
    int counter = 0;
    cout << "Is registered for: \n";
    while(numCredits <= creditsAvail && counter != (int) (toRegister.size())){
        //iterates through all the classes
        for(UnivClass temp : classList){
            //checks to see if the class to register matches the class input
            if(toRegister.at(counter) == temp.getcNumber()){
                //checks to make sure the class wont add more credits than available
                if(numCredits + temp.getCredits() <= creditsAvail){
                    cout << temp << endl;
                    numCredits += temp.getCredits();
                } else{
                    //prints the can't register message.
                    cout << "Could not register for " << temp.getcNumber() << endl;
                }
            }
        }
        counter++;
    }
}

int main(void){
    vector<Employee> empList;
    vector<Student> studList;
    vector<UnivClass> classList;
    vector<string> toRegister;
    string name;
    string classes;
    string temp;
    int credits;

    //read in and populate the employee, student and class arrays.
    ReadUnivClass(classList);
    ReadStudent(studList);
    ReadEmployee(empList);

    //read in name of person
    cout << "Enter first name and last name: \n";
    getline(cin, name);
    
    //read in the classes to register
    cout << "Enter classes to take - one line with spaces between: \n";
    getline(cin, classes);
    cout << endl; 
    //cout << name << endl;
    //cout << classes << endl;
    //process classes into a vector of strings with the name of each class
    stringstream s(classes);
    while(getline(s, temp, ' ')){
        toRegister.push_back(temp);
    }
    //search for person and attempt to register them for the classes listed
    credits = FindPrintName(studList, empList, name);
    PrintClassSchedule(classList, toRegister, credits);
}
