import java.io.File;
import java.util.LinkedList;




/**
*
* @author yaw
*/
public class BFS {

   /**
    * @param args the command line arguments
    */
   public static void main(String[] args) {
	   int start = Integer.parseInt(args[1]);
	   int end = Integer.parseInt(args[2]);
	   Graph myGraph = new Graph(args[0]);
	   if(end >= myGraph.getNumVertices()) {
		   System.out.println("The path you are searching for doesn't exist");
	   } else {
		   BreadthFirstSearch graph; 	   
		   LinkedList<Integer> path = new LinkedList<>();
    	      
		   //search for path between arg[1] and arg[2]
		   graph = new BreadthFirstSearch(myGraph, start);
		   path = graph.getPathTo(end);
    	   
		   //print out the path nicely :P
		   System.out.println("Route: ");
		   for(int i = 0; i < path.size(); i++) {
			   if(i == path.size() - 1) {
				   System.out.print(path.get(i));
			   } else {
				   System.out.print(path.get(i) + " -> ");
			   }
		   }
	   }
   }
}

