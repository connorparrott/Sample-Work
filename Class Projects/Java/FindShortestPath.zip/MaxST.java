

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.LinkedList;
import java.util.HashMap;

/**
*
* @author yaw
*/
public class MaxST {

   /**
    * @param args the command line arguments
    */
	private static EdgeWeightedGraph loadGraph(String file) {
		EdgeWeightedGraph graph = new EdgeWeightedGraph(1); //idk how to initialize this so it wont break... could put in an if statement to check but hey
		try {
	 		   File fptr = new File(file);
	 		   BufferedReader br = new BufferedReader(new FileReader(fptr));
	 		   int numVertices = Integer.parseInt(br.readLine());
	 		   int vertex1;
	 		   int vertex2;
	 		   double weight;
	 		  
	 		   graph = new EdgeWeightedGraph(numVertices);
	 		   
	 		   String edges;
	 		   while((edges = br.readLine()) != null) {
	 			   String[] temp = edges.split(",");
	 			   vertex1 = Integer.parseInt(temp[0]);
	 			   vertex2 = Integer.parseInt(temp[1]);
	 			   weight = (Double.parseDouble(temp[2]));
	 			   graph.addEdge(vertex1, vertex2, -weight);
	 		   }
	 		   br.close();
	 	   }
	 	   catch (Exception e) {
	 		   e.printStackTrace();
	 	   }
		
		return graph;
    }
	
   public static void main(String[] args) {
	   EdgeWeightedGraph graph = loadGraph(args[0]);
       MinimumSpanningTree mst = new MinimumSpanningTree(graph);
       for(Edge edge : mst.getMST()) {
    	   int[] vertices = edge.getVertices();
    	   System.out.println("(" + vertices[0] + "," + vertices[1] + "): " + -1 * edge.getWeight());
       }
   }
   
}