package inheritanceLab;

public class Commissioned extends Employee {
	protected double commissionRate;
	protected int grossSales;
	
	public Commissioned() {
		commissionRate = 0;
		grossSales = 0;
	}
	
	public Commissioned(String firstName, String lastName, double commissionRate, int grossSales) {
		super(firstName, lastName);
		this.commissionRate = commissionRate;
		this.grossSales = grossSales;
	}
	
	public String toString() {
		return "Employee ID: " + idNumber + " First Name: " + firstName + " Last Name: " + lastName + "Comission Rate: " + commissionRate + " Gross Sales " + grossSales;
	}
}
