package inheritanceLab;

public class Employee {
	public static int idNumber;
	protected String firstName;
	String lastName;
	
	public Employee() {
		firstName = null;
		lastName = null;
	}
	public Employee(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
		idNumber++;
	}
	
	public String toString() {
		return "Employee ID: " + idNumber + " First Name: " + firstName + " Last Name: " + lastName;
	}

}
