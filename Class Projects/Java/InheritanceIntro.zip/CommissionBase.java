package inheritanceLab;

public class CommissionBase extends Commissioned {
	protected double baseSalary;
	
	public CommissionBase() {
		baseSalary = 0;
	}
	
	public CommissionBase(String firstName, String lastName, double commissionRate, int grossSales, int baseSalary) {
		super(firstName, lastName, commissionRate, grossSales);
		this.baseSalary = baseSalary;
		
	}
	
	public String toString() {
		return "Employee ID: " + idNumber + " First Name: " + firstName + " Last Name: " + lastName + "Comission Rate: " + commissionRate + " Gross Sales " + grossSales + "Base Salary: " + baseSalary;
	}
}
