package inheritanceLab;

public class Hourly extends Employee{
	protected int hoursWorked;
	protected double hourlyWage;
	
	public Hourly() {
		hoursWorked = 0;
		hourlyWage = 0;
	}
	
	public Hourly(String firstName, String lastName, double wage, int hours) {
		super(firstName, lastName);
		hoursWorked = hours;
		hourlyWage = wage;
	}
	
	public String toString() {
		return "Employee ID: " + idNumber + " First Name: " + firstName + " Last Name: " + lastName + "Hours Worked: " + hoursWorked + " Hourly Wage " + hourlyWage;
	}
}
