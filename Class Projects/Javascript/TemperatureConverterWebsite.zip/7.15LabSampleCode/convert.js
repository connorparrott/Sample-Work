window.addEventListener("DOMContentLoaded", domLoaded);

function domLoaded() {
    document.getElementById("convertButton").addEventListener("click", convert); //can't have parentheses after convert if nothing is being passed in :P
    document.getElementById("cInput").addEventListener("input", clearF)
    document.getElementById("fInput").addEventListener("input", clearC)
}

function convert(){
    let temp = ""
    let c = document.getElementById("cInput").value
    let f = document.getElementById("fInput").value

    if(/[a-z]/i.test(f)){
        temp = f
        f = NaN
        c = NaN
    }else if (/[a-z]/i.test(c)){
        temp = c
        f = NaN
        c = NaN
    }
    c = parseFloat(c)
    f = parseFloat(f)

    let result = 0
    if(!isNaN(c)){
        result = convertCtoF(c)
        document.getElementById("fInput").value = result
        changePicture(result)
        //console.log(result)

    } else if(!isNaN(f)){
        result = convertFtoC(f)
        document.getElementById("cInput").value = result
        changePicture(f)
        //console.log(result)
    } else{
            document.getElementById("errorMessage").innerHTML = temp + " is not a number"
    }
}

function clearF(){
    document.getElementById("fInput").value = ""
}
function clearC(){
    document.getElementById("cInput").value = ""
}

function changePicture(F){
    if(F <= 32){
        document.getElementById("weatherImage").src = "cold.png"
    } else if(F <= 50){
        document.getElementById("weatherImage").src = "cool.png"
    } else {
        document.getElementById("weatherImage").src = "warm.png"
    }
}

function convertCtoF(degreesCelsius) {
   return degreesCelsius * 9/5 + 32
}

function convertFtoC(degreesFahrenheit) {
   return ((degreesFahrenheit - 32) * 5/9)
}
