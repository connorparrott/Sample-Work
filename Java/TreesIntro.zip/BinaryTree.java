package Lab4;

import java.util.ArrayList;

/**
 *
 * @author yaw
 */
public class BinaryTree {

    public Node root;
    private Node current;

    public BinaryTree() {
        root = null;
    }

    public void insert(int newValue) {
        if (root == null) {
            root = new Node(newValue);
        } else {
            Node currentNode = root;
            boolean placed = false;
            while (!placed) {
                if (newValue < currentNode.getValue()) {
                    if (currentNode.getLeft() == null) {
                        currentNode.setLeft(new Node(newValue));
                        currentNode.getLeft().setParent(currentNode);
                        placed = true;
                    } else {
                        currentNode = currentNode.getLeft();
                    }
                } else {
                    if (currentNode.getRight() == null) {
                        currentNode.setRight(new Node(newValue));
                        currentNode.getRight().setParent(currentNode);
                        placed = true;
                    } else {
                        currentNode = currentNode.getRight();
                    }
                }
            }
        }
    }

    public void modify(int oldValue, int newValue) {
        if (root != null) {
            Node currentNode = root;
            boolean found = false;
            while (!found) {
                if (oldValue < currentNode.getValue()) {
                    if (currentNode.getLeft() != null) {
                        currentNode = currentNode.getLeft();
                    } else {
                        System.out.println("Value not in tree.");
                        found = true;
                    }
                } else if (oldValue > currentNode.getValue()) {
                    if (currentNode.getRight() != null) {
                        currentNode = currentNode.getRight();
                    } else {
                        System.out.println("Value not in tree.");
                        found = true;
                    }
                } else {
                    currentNode.setValue(newValue);
                    found = true;
                }
            }
        }
    }

    public boolean isBST() {
        //Is the left child less than the current node. Is the Right child greater than the current node.
    	//Search through the tree and check. Recursion would be good.
    	current = root;
    	ArrayList<Integer> inOrder = new ArrayList<>();
    	ArrayList<Integer> temp = searchTree(current, inOrder);
    	//System.out.println("Root " + root.getValue() + " ArrayList: " + temp);
    	boolean isBST = true;
		//System.out.println("SIZE: " + inOrder.size());
		
		for(int i = 1; i < inOrder.size(); i++) {
			if(inOrder.get(i-1) > inOrder.get(i)) {
				isBST = false;
			}
		}
			return isBST;
    }
    
    public ArrayList<Integer> searchTree(Node node, ArrayList<Integer> inOrder) {
    	if(node == null) {
    		return inOrder;
    	}
    	
    		//System.out.println(node.getValue() + "is greater than " + node.getLeft().getValue() + " and is less than " + node.getRight().getValue() );
    		searchTree(node.getLeft(), inOrder);
    		inOrder.add(node.getValue());
    		searchTree(node.getRight(), inOrder);
    		return inOrder;
    	
    }
    
    public void printTree(Node node) {
    	if(node != null) {
    		printTree(node.getLeft());
    		System.out.println(node.getValue());
    		printTree(node.getRight());
    	}
    	
    }
}

