package Lab4;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author yaw
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();
        tree.insert(51);
        tree.insert(44);
        tree.insert(21);
        tree.insert(1);
        tree.insert(5);
        tree.insert(55);
        tree.insert(100);
        tree.insert(65);
        tree.insert(76);
        tree.insert(200);
        tree.insert(23);
        tree.insert(15);
        tree.insert(789);
        tree.printTree(tree.root);
        
        if(tree.isBST()) {
        	System.out.println("The tree is a binary search tree.");
        } else {
        	System.out.println("The tree is NOT a binary search tree.");
        }
        
        tree.modify(21, 100);
        //tree.modify(55, 1);
        tree.printTree(tree.root);
        
        
        if(tree.isBST()) {
        	System.out.println("The tree is a binary search tree.");
        } else {
        	System.out.println("The tree is NOT a binary search tree.");
        }
    }
}

