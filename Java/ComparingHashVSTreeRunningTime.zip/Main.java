
import java.util.Random;
import java.util.TreeSet;


public class Main {


    public static void main(String[] args) {
        int[] sizes = {500000, 750000, 1000000, 1250000, 1500000, 2000000, 5000000, 10000000};
        double hashSetInsertionAverage = 0;
        double hashSetSearchAverage = 0;
        double treeSetInsertionAverage = 0;
        double treeSetSearchAverage = 0;

        for (int size : sizes) {
            System.out.println("Size,Iteration,Insertion_time,Search_time");
            for (int iteration = 0; iteration < 10; iteration++) {
                long seed = System.currentTimeMillis();
                Random r = new Random(seed);

                // Insertion test SC.
                SeparateChainingHashSet hashSet = new SeparateChainingHashSet();
                long startTime = System.nanoTime();
                for (int i = 0; i < size; i++) {
                    hashSet.add(r.nextInt());
                }
                long elapsedTime = System.nanoTime() - startTime;
                hashSetInsertionAverage += (elapsedTime / 1000000000.0);
                System.out.print(size + "," + iteration + "," + (elapsedTime / 1000000000.0));
                
                // Search test SC.
                startTime = System.nanoTime();
                for (int i = 0; i < 10000; i++) {
                    hashSet.contains(r.nextInt());
                }
                elapsedTime = System.nanoTime() - startTime;
                hashSetSearchAverage += (elapsedTime / 1000000000.0);
                System.out.println("," + (elapsedTime / 1000000000.0));
                
                
                //TREEEE
                
                
                //Insertion test tree.
                r = new Random(seed);
                TreeSet<Integer> tree = new TreeSet<>();
                startTime = System.nanoTime();
                for (int i = 0; i < size; i++) {
                    tree.add(r.nextInt());
                }
                elapsedTime = System.nanoTime() - startTime;
                treeSetInsertionAverage += (elapsedTime / 1000000000.0);
                System.out.print(size + "," + iteration + "," + (elapsedTime / 1000000000.0));
                
                // Search test tree.
                startTime = System.nanoTime();
                for (int i = 0; i < 10000; i++) {
                    tree.contains(r.nextInt());
                }
                elapsedTime = System.nanoTime() - startTime;
                treeSetSearchAverage += (elapsedTime / 1000000000.0);
                System.out.println("," + (elapsedTime / 1000000000.0));
                
            }
            
            System.out.println();
            System.out.println("HashSet Insertion Average: " + (hashSetInsertionAverage)/10); //could replace this with numTests if you want it to be scalable
            System.out.println("HashSet Search Average: " + (hashSetSearchAverage)/10); 
            System.out.println("TreeSet Insertion Average: " + (treeSetInsertionAverage)/10); //same here
            System.out.println("TreeSet Search Average: " + (treeSetSearchAverage)/10); 
            System.out.println();
        }
    }
}
