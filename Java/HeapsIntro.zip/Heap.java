package Heaps;

public class Heap {
	private static int[] heap = new int[25];
	static int index = 0;



	public static void insert(int a) {
		heap[index] = a;
		swap();
		index++;
	}
	
	public static void remove() {

		//remove the top
		 heap[0] = heap[index -1];
		 heap[index-1] = 0;
		 
		 for(int i = 0; i < index; i++) {
			 int leftChild = (i*2) +1;
			 int rightChild = (i*2) +2;
			 int temp = 0;
			 
			 if(heap[leftChild] < heap[i]) {
				 if(heap[leftChild] != 0) {
				 temp = heap[i];
				 heap[i] = heap[leftChild];
				 heap[leftChild] = temp;
				 if(heap[rightChild] < heap[i]) {
					 if(heap[rightChild] != 0) {
						 temp= heap[i];
						 heap[i] = heap[rightChild];  
						 heap[rightChild] = temp;
						 }
				 }
				 }
			 } else if(heap[rightChild] < heap[i]) {
				 if(heap[rightChild] != 0) {
				 temp= heap[i];
				 heap[i] = heap[rightChild];  
				 heap[rightChild] = temp;
				 }
			 }
		 }
		 index--;
	}
	
	public static void print() {
		for(int i = 0; i < heap.length; i++) {
			System.out.println(heap[i]);
		}
	}
	public static void swap() {
		int parent = ((index-1)/2);
		if(heap[index] < heap[parent]) {
			int temp = heap[parent];
			heap[parent] = heap[index];
			heap[index] = temp;
		}
	}
}
