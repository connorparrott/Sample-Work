package Heaps;

public class Driver {
	public static void main(String[] args) {
		Heap.insert(15);
		Heap.insert(5);
		Heap.insert(8);
		Heap.insert(4);
		Heap.insert(9);
		Heap.insert(22);
		Heap.insert(17);
		Heap.insert(6);
		Heap.insert(14);
		Heap.print();
		System.out.println("END OF OPERATION");
		Heap.remove();
		Heap.remove();
		System.out.println("END OF OPERATION");
		Heap.print();
		Heap.insert(18);
		Heap.insert(12);
		System.out.println("END OF OPERATION");
		Heap.print();
		Heap.remove();
		Heap.remove();
		Heap.remove();
		System.out.println("END OF OPERATION");
		Heap.print();
	}
}
