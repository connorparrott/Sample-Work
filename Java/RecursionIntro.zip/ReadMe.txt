The other .txt files in this folder are sample mazes that the program will read in and find the path recursively. They need to be in the main folder of the package,
not with the code like they are in this .zip
