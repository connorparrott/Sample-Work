package Mario;

public class Jumping implements State{
	
	private MarioStateDiagram marioSimulation;
	public Jumping(MarioStateDiagram m) {
		marioSimulation = m;
	}
	
	@Override
	public void crouching() {
		System.out.println("Mario is now crouching");
		marioSimulation.setState(marioSimulation.getCrouching());
	}

	@Override
	public void standing() {
		System.out.println("Mario is now standing");
		marioSimulation.setState(marioSimulation.getStanding());
	}

	@Override
	public void running() {
		System.out.println("Mario is now running");
		marioSimulation.setState(marioSimulation.getRunning());
		
	}

	@Override
	public void dead() {
		System.out.println("You surrendered! Mario is dead");
		marioSimulation.setState(marioSimulation.getDead());
		
	}

	@Override
	public void jumping() {
		System.out.println("Mario is still jumping");
		
	}
	@Override
	public void fireball() {
		System.out.println("Whew, that was close! Mario jumped over the fireball");
	}	
}
