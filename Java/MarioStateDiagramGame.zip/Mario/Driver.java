package Mario;
import java.util.Scanner;

public class Driver {
	public static void main(String[] args) {
		MarioStateDiagram marioSimulation = new MarioStateDiagram();
		Scanner input = new Scanner(System.in); 
		
		while(marioSimulation.getCurrentState() != marioSimulation.getDead()) {
			System.out.println("What would you like mario to do? ('j'ump, 'c'rouch, 'r'n, 's'tand, 'd'ie, or 'f'ireball)");
			String temp = input.next();
			if(temp.toLowerCase().equals("j")) {
				marioSimulation.jump();
			} else if(temp.toLowerCase().equals("c")) {
				marioSimulation.crouch();
			} else if(temp.toLowerCase().equals("r")) {
				marioSimulation.run();
			} else if(temp.toLowerCase().equals("s")) {
				marioSimulation.stand();
			} else if(temp.toLowerCase().equals("d")) {
				marioSimulation.die();
			} else if(temp.toLowerCase().equals("f")){
				marioSimulation.fireball();
			} else {
				System.out.println(temp + " was not a recognized action for Mario. Please submit this action to the Mario remake github so that we can look to add it in the next update!");
			}
		}
		System.out.println("Game Over! Mario has died!");
		input.close();
	}
}
