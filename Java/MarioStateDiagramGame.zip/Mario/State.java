package Mario;

public interface State {
	public void crouching();
	public void standing();
	public void running();
	public void dead();
	public void jumping();
	public void fireball();
}
