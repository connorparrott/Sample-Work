package Mario;

public class Dead implements State{
	
	private MarioStateDiagram marioSimulation;
	public Dead(MarioStateDiagram m) {
		marioSimulation = m;
	}
	
	@Override
	public void crouching() {
		System.out.println("Mario is dead! He can't crouch");
		
	}

	@Override
	public void standing() {
		System.out.println("Mario is dead! He can't stand");
		
	}

	@Override
	public void running() {
		System.out.println("Mario is dead! He can't run");
		
	}

	@Override
	public void dead() {
		System.out.println("Mario is already dead!");
		
	}

	@Override
	public void jumping() {
		System.out.println("Mario is dead! He can't jump");
		
	}
	@Override
	public void fireball() {
		System.out.println("Mario is already dead! The fireball can't kill him again");
	}
}
