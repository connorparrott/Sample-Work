package Mario;

public class Crouching implements State{
	private MarioStateDiagram marioSimulation;
	public Crouching(MarioStateDiagram m) {
		marioSimulation = m;
	}
	@Override
	public void crouching() {
		System.out.println("Mario is already Crouching");
	}

	@Override
	public void standing() {
		System.out.println("Mario is now Standing");
		marioSimulation.setState(marioSimulation.getStanding());
	}

	@Override
	public void running() {
		System.out.println("Mario can't start running from a crouch. He is now standing");
		marioSimulation.setState(marioSimulation.getStanding());
	}

	@Override
	public void dead() {
		System.out.println("You surrendered! Mario is dead");
		marioSimulation.setState(marioSimulation.getDead());
	}

	@Override
	public void jumping() {
		System.out.println("Mario is now Jumping");
		marioSimulation.setState(marioSimulation.getJumping());
		
	}
	@Override
	public void fireball() {
		System.out.println("Whew, that was close, Mario dodged the fireball");
	}
	
}
