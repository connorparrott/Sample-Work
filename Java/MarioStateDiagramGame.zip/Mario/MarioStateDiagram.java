package Mario;

public class MarioStateDiagram {
	private State jumping;
	private State running;
	private State standing;
	private  State crouching;
	private State dead;
	
	private State currentState;
	
	public MarioStateDiagram() {
		jumping = new Jumping(this);
		running = new Running(this);
		standing = new Standing(this);
		crouching = new Crouching(this);
		dead = new Dead(this);
		
		currentState =  standing;
	}
	public void setState(State state) {
		this.currentState = state;
	}
	public State getCurrentState() {
		return currentState;
	}
	
	public State getJumping() {
		return jumping;
	}
	public State getRunning() {
		return running;
	}
	public State getStanding() {
		return standing;
	}
	public State getCrouching() {
		return crouching;
	}
	public State getDead() {
		return dead;
	}
	public void fireball() {
		currentState.fireball();
	}
	//Commands
	public void run() {
		currentState.running();
	}
	public void jump() {
		currentState.jumping();
	}
	public void die() {
		currentState.dead();
	}
	public void crouch() {
		currentState.crouching();
	}
	public void stand() {
		currentState.standing();
	}
}
