package Mario;

public class Running implements State{
	
	private MarioStateDiagram marioSimulation;
	public Running(MarioStateDiagram m) {
		marioSimulation = m;
	}
	
	@Override
	public void crouching() {
		System.out.println("Mario has to stop running before he can crouch! Mario is now standing");
		marioSimulation.setState(marioSimulation.getStanding());
		
	}

	@Override
	public void standing() {
		System.out.println("Mario is now standing");
		marioSimulation.setState(marioSimulation.getStanding());
		
	}

	@Override
	public void running() {
		System.out.println("Mario is still running");
		
	}

	@Override
	public void dead() {
		System.out.println("You surrendered, Mario is dead");
		marioSimulation.setState(marioSimulation.getDead());
	}

	@Override
	public void jumping() {
		System.out.println("Mario is now jumping");
		marioSimulation.setState(marioSimulation.getJumping());
		
	}
	@Override
	public void fireball() {
		System.out.println("Mario ran into a fireball!");
		marioSimulation.setState(marioSimulation.getDead());
	}
}
