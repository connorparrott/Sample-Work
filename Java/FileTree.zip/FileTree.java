package Week2;
import java.util.ArrayList;

//Put info to insert, delete and navigate the tree
//Can also create an interface between user commands and tree object operations

public class FileTree {
	
	private Node root;
	private Node current;
	
	public FileTree() {
		root = new Node("~");
		current = root;
	}
	
	public String getCurrentLocation() {
		return current.getName();
	}
	
	//return boolean so it will return false if there is no such directory
	public boolean moveDown(String directory) {
		ArrayList<Node> children = current.getChildren();
		for(Node child : children) {
			if(directory.equals(child.getName())) {
				current = child;
				return true;
			}
		}
		return false;
	}
	
	public void moveUp() {
		if(current != root) {
		current = current.getParent();
		}
	}
	
	public void goHome() {
		current = root;
	}
	
	public String getChildren() {
		String files = "";
		ArrayList<Node> children = current.getChildren();
		for(Node child : children = current.getChildren()) {
			files += child.getName() + " ";
		}
		return files;
	}
	
	public boolean insert(String directory) {
		if(directory!= null && !directory.equals("")) {
		Node newNode = new Node(directory);
		newNode.setParent(current);
		current.addChild(newNode); //Both lines required as we need to both set the newNodes parent and add the newNode to currents children. Need to tell both.
		return true;
		}
		return false;
	}
	
	public String getPath() {
		Node temporary = current;
		String path = "";
		while(temporary != null) {
			path = "/" + temporary.getName() + path; //I think this is backwards, need to add to the front of the string?
			temporary = temporary.getParent();
		}
		return path;
	}
	
	
	public boolean remove(String directory) {
		
		return false;
	}
}
