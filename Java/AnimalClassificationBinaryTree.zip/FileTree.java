package project1;

import java.io.*;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Queue;

public class FileTree {

    public Node root;
    private Node current;
    private String printLine;
    private String numberLine;
    private int count;


    public FileTree() {
        /*
    	root = new Node("furry");
        Node left = new Node("dog");
        Node right = new Node("snake");
        root.setLeft(left);
        left.setParent(root);
        root.setRight(right);
        right.setParent(root);
        */
        current = root;

    }

    public String getCurrentLocation() {
        return current.getName();
    }

    public boolean hasChildren() {
        if (current.getLeft() != null) {
            return false;
        } else if (current.getRight() != null) {
            return false;
        }
        return true;
    }

    public boolean insert(String directory) {
        boolean placed = false;
        while (!placed) {
            if (root == null) {
                root = new Node(directory);
            } else {
                if (current.getLeft() == null) {
                    current.setLeft(new Node(directory));
                    current.getLeft().setParent(current);
                    placed = true;
                } else {
                    current = current.getLeft();
                }

                if (current.getRight() == null) {
                    current.setRight(new Node(directory));
                    current.getRight().setParent(current);
                    placed = true;
                } else {
                    current = current.getRight();
                }

                return true;
            }
        }
        return false;
    }

    public boolean swap(String name, String leftChild, String rightChild) {
        Node left;
        Node right;
        current.setName(name);

        left = new Node(leftChild);
        current.setLeft(left);
        left.setParent(current);

        right = new Node(rightChild);
        current.setRight(right);
        right.setParent(current);
        return true;
    }

    public boolean moveLeft() {

        if (current.getLeft() != null) {
            current = current.getLeft();
            return true;
        } else {
            return false;
        }
        //ArrayList<Node> children = current.getChildren();
        /*
    	for (Node child : children) {
            if (directory.equals(child.getName())) {
                current = child;
                return true;
            }
        }
        return false;
        */

    }

    public boolean moveRight() {
        if (current.getRight() != null) {
            current = current.getRight();
            return true;
        } else {
            return false;
        }
    }


    public void goHome() {
        current = root;
    }

    public String getPath(String not) {
        Node nodePointer = current;
        String path = "";
        String output = "";
        while (nodePointer != root) {
            path = "/" + nodePointer.getName() + path;
            nodePointer = nodePointer.getParent();
        }
        path = nodePointer.getName() + path;

        String[] split = path.split("/");
        String[] split2 = not.split("/");

        output = "I don't know of any ";
        for (int i = 0; i < split.length - 1; i++) {
            if (split2[i].equals("N")) {
                output += "not " + split[i];
                if (i + 1 != split.length - 1) {
                    output += ", ";
                } else {
                    output += " ";
                }
            } else {
                output += split[i];
                if (i + 1 != split.length - 1) {
                    output += ", ";
                } else {
                    output += " ";
                }
            }
        }
        output += "animals that aren�t a " + split[split.length - 1] + ".";
        //output +=;
        //System.out.println(not);
        return output;
    }

/*
    public void depthFirstRec() {
        count = 0;
        printLine = "";
        numberLine = "";
        depthFirstRec(root);

        for (int i = 1; i < count + 1; i++) {
            numberLine += i + ", ";
        }
        
        writeFile(printLine);
        
    }
*/
    
    
    public String breadthFirst() {
    	Queue<Node> queue = new LinkedList<Node>();
    	String printLine = "";
    	depthFirstRec(root);
    	queue.add(root);
    	
    	while(!queue.isEmpty()) {
    		Node temp = queue.poll();
    		printLine += (temp.getName() + "#" + temp.getValue() + ", ");
    		
    		if(temp.getLeft() != null) {
    			queue.add(temp.getLeft());
    		} 
    		if(temp.getRight() != null) {
    			queue.add(temp.getRight());
    		} 
    	}
    	return printLine;
    }
   
    public void depthFirstRec(Node node) {
    	int value = 1;
        if (node != null) {
        	depthFirstRec(node.getLeft());
        	node.setValue(value);
            depthFirstRec(node.getRight());
            
        }
    }

    
    public void writeFile(String names) {
        PrintWriter pw = null;

        try {
            File file = new File("animalTree.txt");
            FileWriter fw = new FileWriter(file);
            pw = new PrintWriter(fw);

            pw.println(names);
            //pw.println(numbers);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (pw != null) {
                pw.close();
            }
        }
    }
    public String[][] readFile() {
        Scanner scn = null;
        String text = "";

        try {
            scn = new Scanner(new File("animalTree.txt"));
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        while (scn.hasNext()) {
            text += scn.next();
        }
        String[] arry = text.split(",");
        
        String[][] value = new String [1000][1000];
      //This sucks but it works? And im kinda done ngl <3
        for(int i = 0; i < arry.length; i++) {
        	value[i] = arry[i].split("#");
        }
      
        System.out.println(Arrays.toString(arry));
        return value;
    }
    
    public void buildTree(String[][] inputTree) {
    	for(int i = 0; i < inputTree.length; i++) {
    		
    		//This sucks but it works? And im kinda done ngl <3
    		
    		//System.out.println(inputTree[i]);
    		
    		if(root == null) {
    			root = new Node(inputTree[i][0], Integer.valueOf(inputTree[i][1]));
    			//System.out.println("Created root!");
    			current = root;
    		} else {
    			if(i < current.getValue()) {
    				if(current.getLeft() == null) {	
    					current.setLeft(new Node(inputTree[i][0], Integer.valueOf(inputTree[i][1])));
    					current.getLeft().setParent(current);
    					current = current.getLeft();
    					//System.out.println("created a left Node for "+ inputTree[i]);
    				} 
    			}else{
    				if(current.getRight() == null) {
    					System.out.println(inputTree[i][0] + " " + inputTree[i][1]);
    					current.setRight(new Node(inputTree[i][0], Integer.valueOf(inputTree[i][1])));
    					current.getRight().setParent(current);
    					//System.out.println("created a right Node for "+ inputTree[i]);
    					current = current.getRight();
    				}
    			}
    		}
    	}
    	}
    }

