
package project1;
import java.util.Scanner;

public class UserInteraction {

    private FileTree tree;

    public UserInteraction() {
        tree = new FileTree();
    }
    public void run() {
        // reload tree from readFile()
        String [][] inputTree = tree.readFile();
        tree.buildTree(inputTree);

        String command = " ";
        Scanner in = new Scanner(System.in);
        while (!command.equals("N")) {
            System.out.print("Do you have another animal to identify? (Y/N) > ");
            command = in.nextLine();
            if (command.equals("Y")) {
                executeCommand();
            }
        }
        // write to file
        tree.writeFile(tree.breadthFirst());
    }

    private void executeCommand() {
        String newAnimal;
        String characteristic;
        String oldAnimal;
        String command = " ";
        String not = ""; // keeps track of yes or no for formatting
        Scanner in = new Scanner(System.in);

        tree.goHome();

        while (!tree.hasChildren()) {
            System.out.print("Is this animal " + tree.getCurrentLocation() + "? (Y/N) > ");
            command = in.nextLine();
            not += command + "/";
            if(command.equals("Y")) {
                tree.moveLeft();
            } else if(command.equals("N")){
                tree.moveRight();
            } else {
                System.out.println("Invalid answer, please try again (Y/N) > ");
                command = in.nextLine();
            }

        }
        System.out.print("Is this animal a " + tree.getCurrentLocation() + "? (Y/N) > ");
        command = in.nextLine();
        not += command + "/";

        if (command.equals("Y")) {
            System.out.println("Good.\n");

        } else if (command.equals("N")) {
            System.out.println(tree.getPath(not));
            // position classification in tree
            System.out.print("What is the new animal? > ");
            command = in.nextLine();
            newAnimal = command;
            System.out.print("What characteristic does a " + newAnimal + " have that a " +
                    tree.getCurrentLocation() + " does not? > ");
            command = in.nextLine();
            System.out.println();
            characteristic = command;

            // swap current
            oldAnimal = tree.getCurrentLocation();
            tree.swap(characteristic, newAnimal, oldAnimal);

        }
        tree.goHome();
    }
}