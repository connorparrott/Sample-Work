package Week2;
import java.util.ArrayList;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Stack;

//Put info to insert, delete and navigate the tree
//Can also create an interface between user commands and tree object operations

public class FileTree {
	
	private Node root;
	private Node current;
	
	public FileTree() {
		root = new Node("~");
		current = root;
	}
	
	public String getCurrentLocation() {
		return current.getName();
	}
	
	//return boolean so it will return false if there is no such directory
	public boolean moveDown(String directory) {
		ArrayList<Node> children = current.getChildren();
		String [] path;
		path = directory.split("/");
		
		for(int i = 0; i < path.length; i++) {
			for(Node child : children) {
				if(path[i].equals(child.getName())) {
					//System.out.println(current.getName());
					current = child;
					children = current.getChildren();
					//System.out.println(current.getName());
				} 
			}
			
			if(path[path.length-1].equals(current.getName())) {
				return true;
			}
		}
		return false;
	}
	
	public void moveUp() {
		if(current != root) {
		current = current.getParent();
		}
	}
	
	public void goHome() {
		current = root;
	}
	
	public String getChildren() {
		String files = "";
		ArrayList<Node> children = current.getChildren();
		for(Node child : children = current.getChildren()) {
			files += child.getName() + " ";
		}
		return files;
	}
	
	public boolean insert(String directory) {
		if(directory!= null && !directory.equals("")) {
		Node newNode = new Node(directory);
		newNode.setParent(current);
		current.addChild(newNode); //Both lines required as we need to both set the newNodes parent and add the newNode to currents children. Need to tell both.
		return true;
		}
		return false;
	}
	
	public String getPath() {
		Node temp = current;
		String path = "";
		while(temp != null) {
			path =  "/" + temp.getName() + path; 
			temp = temp.getParent();
		}
		return path;
	}
	
	
	public boolean remove(String directory) {
		ArrayList<Node> children = current.getChildren();
		for(Node child : children) {
			if(child.getName().equals(directory)){
				child.setParent(null);
				current.removeChild(child);
				return true;
			}
		}
		return false;
	}
	
	//If you want to make a tree that looks like a tree, breadth first is where its at. Can use null nodes to differentiate between generations and cousins
	//during processing, can read the nulls and write the formatting.
	//breadth first traversal that prints the tree
	public void breadthFIrst() {
		Queue<Node> queue = new LinkedList<>();
		if(root != null) {
			queue.add(root);
		}
		
		while(!queue.isEmpty()) {
			Node node = queue.remove();
			
			//DO ACTION.
			System.out.println(node.getName());
			
			//ADD CHILDREN TO THE QUEUE
			
			for(Node child : node.getChildren()) {
				queue.add(child);
			}
			
		}
	}
	
	//Depth first need a stack
	public void depthFirst() {
		Stack<Node> stack = new Stack<>();
		if(root != null) {
			stack.push(root);
		}
		
		while(!stack.isEmpty()) {
			Node node = stack.pop();
			
			//DO ACTION.
			System.out.println(node.getName());
			
			//ADD CHILDREN TO THE STACK
			
			/*
			//adds children in order, and removes them in reverse order...
			//if we want it to be in order, need to add the children in reverse.
			for(Node child : node.getChildren()) {
				stack.push(child);
			}
			*/
			
			//adds the children in reverse order, thus it will print them in the order we expect.
			for(int i = node.getChildren().size() - 1; i >= 0; i--) {
				stack.push(node.getChildren().get(i));
			}
			
			//CAN ALSO DO DEPTH FIRST VIA RECURSION
			
		}
	}
	
	
	//Can lead to stack overflow errors if the tree is large enough. 
	public void depthFirstRec(Node node) {
		//DO ACTION
		System.out.println(node.getName());
		
		//RECURSIVELY GOES THROUGH THE CHILDREN
		for(Node child : node.getChildren()) {
			depthFirstRec(child);
		}
	}
}
