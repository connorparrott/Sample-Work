package Week2;
import java.util.ArrayList;

public class Node {
	
	private Node parent;
	private ArrayList<Node> children;
	private String name; //data, payload, depends on particular implementations
	
	public Node(String name) {
		this.name = name;
		children = new ArrayList<>();
		parent = null;
	}

	//Getters
	public String getName() {
		return name;
	}

	public Node getParent() {
		return parent;
	}
	
	public ArrayList<Node> getChildren() {
		//currently returns a pointer to protected information. This could be changed by the user. Need to be careful and be sure that that does/doesnt matter.
		//Could return the information inside the ArrayList, the Nodes, for example, or a copy of the ArrayList that isnt the host data. Important in security.
		return children;
	}
	
	
	//Setters
	public void setParent(Node parent) {
		this.parent = parent;
	}
	
	public void addChild(Node child) {
		children.add(child);
	}
	
	public void removeChild(Node child) {
		children.remove(child);
	}
}
