package project1;

import java.util.ArrayList;

public class Node {
    private String name;
    private Node parent;
    private int value; 
    private Node leftChild;
    private Node rightChild;
    
    // I would put a new instance variable
    // called "value" or something in the node class and use that
    // as the binary tree values. Then do the inorder traversal to
    // set the value and do breadth first to print out the values
    // and string "properties".

    //private ArrayList<Node> children;

    public Node(String name) {
        this.name = name;
        leftChild = null;
        rightChild = null;
        //children = new ArrayList<>();
    }
    
    //Reading from File Constructor
    public Node(int value, String name) {
    	this.name = name;
    	this.value = value;
    	leftChild = null;
    	rightChild = null;
    }

    public String getName() {
        return name;
    }
    
    public Node getLeft() {
    	return leftChild;
    }
    
    public Node getRight() {
    	return rightChild;
    }
    
    public void setLeft(Node leftChild) {
    	this.leftChild = leftChild;
    }
    
    public void setRight(Node rightChild) {
    	this.rightChild = rightChild;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public void setParent(Node parent) {
        this.parent = parent;
    }

    public Node getParent() {
        return parent;
    }

    /*
    public ArrayList<Node> getChildren() {
        return children;
    }

    public void addChild(Node child) {
        children.add(child);
    }
    */
    
    //Get Value method
    public int getValue() {
    	return value;
    }
}