
package project1;

import java.io.File;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class FileTree {

    public Node root;
    private Node current;
    private String formatted;
    private String printLine;
    private String numberLine;



    public FileTree() { // maybe read in node from file
        root = new Node("furry");
        Node left = new Node("dog");
        Node right = new Node("snake");
        root.setLeft(left);
        left.setParent(root);
        root.setRight(right);
        right.setParent(root);
        current = root;

    }

    public String getCurrentLocation() {
        return current.getName();
    }

    // getLeft, yesNo -> Y
    // getRight, yesNo -> N
    // can be switched to binary structure
    public String getChildren(String yesNo) {
        //String files[];
        //int i = 0;
        //files = new String[2];
        //ArrayList<Node> children = current.getChildren();
    	//
    	
    	Node child = current;
    	
    	/*
        for (Node child : children) {
            files[i] = child.getName();
            i++;
        }
        */
    	
        if (yesNo.equals("Y")) {
            return child.getLeft().getName();
        } else if (yesNo.equals("N")) {
            return child.getRight().getName();
        }
        return "";
    }

////
    
public boolean hasChildren() {
	if(current.getLeft() != null) {
		return false;
    } else if(current.getRight() != null) {
    	return false;
    }
    return true;
}

/*
    public String hasChildren() {

        String sideOpen = "";
        int count = 0;
        ArrayList<Node> children = current.getChildren();
        for (Node child : children) {
            count++;
        }

        if (count == 0) {
            sideOpen = "leftYes";
        } else if (count == 1) {
            sideOpen = "rightNo";
        } else if (count == 2) {
            sideOpen = "none";
        }
        return sideOpen;
    }

 */
    /////

    public boolean insert(String directory) {
    	boolean placed = false;
    	while(!placed) {
    	if(root == null) {
    		root = new Node(directory);
    	} else {
    	if (current.getLeft() == null) {
            current.setLeft(new Node(directory));
            current.getLeft().setParent(current);
            placed = true;
        } else {
            current = current.getLeft();
        } 
        
        	
        if (current.getRight() == null) {
            current.setRight(new Node(directory));
            current.getRight().setParent(current);
            placed = true;
        } else {
            current = current.getRight();
        }
    	
    	/*
    	if (directory != null && !directory.equals("")) {
            Node newNode = new Node(directory);
            newNode.setParent(current);
            current.addChild(newNode);
            return true;
        }
    	
    	*/
        return true;
    		}
    	}
    	return false;
    }

    public boolean swap(String name, String leftChild, String rightChild) {
    	Node left;
    	Node right;
        current.setName(name);
        
        left = new Node(leftChild);
        current.setLeft(left);
        left.setParent(current);
        
        right = new Node(rightChild);
        current.setRight(right);
        right.setParent(current);
        return true;
    }

    // if getLeft/right exits move down to it
    public boolean moveLeft() {
    	
    	if(current.getLeft() != null) { 
    		current = current.getLeft();
    		return true;
    	} else {
    		return false;
    	}
        //ArrayList<Node> children = current.getChildren();
        /*
    	for (Node child : children) {
            if (directory.equals(child.getName())) {
                current = child;
                return true;
            }
        }
        return false;
        */
    	
    }
    
    public boolean moveRight() {
    	if(current.getRight() != null) {
    		current = current.getRight();
    		return true;
    	} else {
    		return false;
    	}
    }
    

    public void goHome() {
        current = root;
    }

    // REMOVE LATER
    /*
    public String getSubTree() {
        formatted = "";
        getSubTree(current, 0);
        return formatted; // returns full built string
    }

    
    private void getSubTree(Node node, int indentation) {
        String builder = "";

        if (indentation == 1) {
            builder += "|---";
        } else if (indentation > 1) {
            for (int i = 0; i < indentation - 1; i++) {
                builder += "|\t";
            }
            builder += "|---";
        } else {
            builder += "";
        }

        this.formatted += builder + node.getName() + "\n";
        // recursive call
        for (Node c : node.getChildren()) {
            getSubTree(c, indentation + 1);
        }
    }
    */
    /// REMOVE ABOVE PROBABLY




    public String getPath(String not) {
        Node nodePointer = current;
        String path = "";
        String output = "";
        while (nodePointer != root) {
            path = "/" + nodePointer.getName() + path;
            nodePointer = nodePointer.getParent();
        }
        path = nodePointer.getName() + path;

        String[] split = path.split("/");
        String[] split2 = not.split("/");

        output = "I don't know of any ";
        for (int i = 0; i < split.length - 1; i++) {
            if (split2[i].equals("N")) {
                output += "not " + split[i];
                if (i + 1 != split.length - 1) {
                    output += ", ";
                } else {
                    output += " ";
                }
            } else {
                output += split[i];
                if (i + 1 != split.length - 1) {
                    output += ", ";
                } else {
                    output += " ";
                }
            }
        }
        output += "animals that aren�t a " + split[split.length - 1] + ".";
        //output +=;
        //System.out.println(not);
        return output;
    }

    public void depthFirstRec(Node node) {
        //DO ACTION
    	if(node != null) {
    		depthFirstRec(node.getLeft());
    		writeFile(node.getName());
    		depthFirstRec(node.getRight());
    	}
    }
    //////
    private void writeFile(String name) {
        PrintWriter pw = null;

        try {
            File file = new File("animalTree.txt");
            FileWriter fw = new FileWriter(file); // this was to continue writing on same file but we need to
            // write all data onto file from scratch
            pw = new PrintWriter(fw);
            // for value in array write to file
            pw.print(name); // \n to make sure a new line is used.. will have to check line holds
            // values anyways for the end of the file. *But leave cursor on end of last line
            // add ways to put all responses here as well as printing into this file in
            // breath first... assign numbers in depth first

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (pw != null) {
                pw.close();
            }
        }
    }
    public void printTree(Node node) {
    	if(node != null) {
    		printTree(node.getLeft());
    		System.out.println(node.getName());
    		printTree(node.getRight());
    	}
    }
}
    /////////
/*
    public void breadthFirst() {
        numberLine = "";
        Queue<Node> queue = new LinkedList<>();
        if (root != null) {
            queue.add(root);
            while (!queue.isEmpty()) {
                Node node = queue.remove();

                // DO ACION
                //System.out.println(node.getName());
                this.numberLine += node.getName() + ", ";

                for (Node child : node.getChildren()) {
                    queue.add(child);
                } // or can use queue.addAll(node.getChildren) method
            }
        }
        writeFile();
    }

}

*/






/*
 *     private void writeFile() {
    	
    	try {
			//Makes a file called animalList.txt (should be just above the src directory of whatever folder you are currently in)
			File animalList = new File("animalList.txt");
			//Creates a file writer to aforementioned file.
			FileWriter writ = new FileWriter(animalList);
			
			//Recurses through the tree and write names in order to a file.
			inOrderRecurse(root, writ);
			
			writ.close();
		} catch(Exception e) {
			System.out.println("ERROR: unable to write to file");
			e.printStackTrace();
		}
	}
    
   private void inOrderRecurse(Node node, FileWriter writ) {
	   	ArrayList<Node> children = node.getChildren();
	   	
	   	try {
	   		for(Node child : children) {
	   			inOrderRecurse(child, writ);
	   			writ.write(child.getName());
	   			writ.append(", ");
	   		}
	   	
	   	}catch(IOException e) {
	   		System.out.println("ERROR: unable to write to file.");
	   		e.printStackTrace();
	   	}
   }
*/
