package project1;


public class Main {

    public static void main(String[] args) {
        UserInteraction animals = new UserInteraction();
        animals.run();
    }
}

//                               furry
//                        dog             snake
//                            [dog, snake]


//                               furry
//                   squeaky                 snake
//             mouse          dog


//                               furry
//          squeaky                                      aquatic
//     mouse          bipedal                    legged            snake
//             reclusive    dog           shelled      fish
//          bigfoot   human           crab    salamander
