
package project1;
import java.util.Scanner;

public class UserInteraction {

    private FileTree tree;

    public UserInteraction() {
        tree = new FileTree();
    }
    public void run() {
    	//tree.insert("furry");
        // readFile() and build tree maybe done in tree.java

        String command = " ";
        Scanner in = new Scanner(System.in);
        while (!command.equals("N")) {
            System.out.print("Do you have another animal to identify? (Y/N) > ");
            command = in.nextLine();
            if (command.equals("Y")) {
                executeCommand();
            }
        }
        // write to file
        tree.depthFirstRec(tree.root); // 4 testing
        // System.out.println(tree.getSubTree());  // for tests
        //System.out.println(tree.getSubTree());
        //System.out.println();
        //tree.breadthFirst();
    }

    private void executeCommand() {
        String newAnimal;
        String characteristic;
        String oldAnimal;
        String command = " ";
        String not = ""; // keeps track of yes or no for formatting idk that animal printout
        Scanner in = new Scanner(System.in);

        tree.goHome();
        
        while (!tree.hasChildren()) {
        	//System.out.println("Have children");
            System.out.print("Is this animal " + tree.getCurrentLocation() + "? (Y/N) > ");
            command = in.nextLine();
            not += command + "/";
            if(command.equals("Y")) {
            	tree.moveLeft();
            } else if(command.equals("N")){
            	//can add if statement if this is retunring null.
            	tree.moveRight();
            } else {
            	System.out.println("Invalid answer, please try again (Y/N) > ");
            	command = in.nextLine();
            }
            
        }
        System.out.print("Is this animal a " + tree.getCurrentLocation() + "? (Y/N) > ");
        command = in.nextLine();
        not += command + "/";
        
        if (command.equals("Y")) {
            System.out.println("Good.\n");

        } else if (command.equals("N")) {
            System.out.println(tree.getPath(not));
                            //System.out.println(not);
            // position classification in tree
            System.out.print("What is the new animal? > ");
            command = in.nextLine();
            newAnimal = command;
            System.out.print("What characteristic does a " + newAnimal + " have that a " +
                    tree.getCurrentLocation() + " does not? > ");
            command = in.nextLine();
            System.out.println();
            characteristic = command;

            // swap current
            oldAnimal = tree.getCurrentLocation();
            tree.swap(characteristic, newAnimal, oldAnimal);
            
            //tree.moveRight(characteristic);

            // set left and right
        }
        System.out.println("Going Home");
        tree.goHome();
        //tree.printTree(tree.root);
    }
}